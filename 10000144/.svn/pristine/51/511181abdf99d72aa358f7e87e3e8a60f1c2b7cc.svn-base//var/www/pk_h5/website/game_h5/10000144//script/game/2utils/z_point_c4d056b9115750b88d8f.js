/**
 * Created by Christiaan Duim on 30-9-13.
 */

"use strict";

function Point(x, y)
{
    this.x = x;
    this.y = y;
}