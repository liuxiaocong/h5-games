function CollisionTags () {
}

CollisionTags.rocketCollisionType = 1;
CollisionTags.coinCollisionTag = 2;
CollisionTags.fuelCollisionTag = 3;
CollisionTags.mineCollisionType = 4;
CollisionTags.stormyCloudCollisionType = 5;
CollisionTags.missileCollisionType = 6;
CollisionTags.structureCollisionType = 7;
CollisionTags.islandCollisionType = 8;
CollisionTags.darkCloudCollisionType = 9;