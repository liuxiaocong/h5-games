
var gamenametitle = 'xd_spl_act_villainsunite';
document.title = "Villains Unite!";

var gn = gamenametitle.split("_");
/*
var ctoAssetTypeCode = 'gam';
var ctoGameEvent = 'load';
var ctoGameBuCode = 'xd';
var ctoGameSeriesCode = gn[0];
var ctoGameOwnerName = 'dol';
var ctoGameTypeCode = gn[1];
var ctoGameGenreCode = gn[2];
var ctoGameName = gn[3];
var ctoAssetId = '4fa7895272f6b6628dc30504';
*/
function gameStart() {
	SwitEntryPoint.start();
}	