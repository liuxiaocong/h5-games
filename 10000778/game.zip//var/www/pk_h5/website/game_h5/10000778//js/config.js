//var mebtnopenurl = 'http://www.bangbangu.com';// by jiazom\
var mebtnopenurl = './';
/*
var DDL_CONFIG = {
	root_url : 'http://dudulugame.duapp.com',
	root_url_a : 'http://dudulugame.duapp.com/_index.html',
	follow_url : 'http://mp.weixin.qq.com/s?__biz=MzA3MDQzNzIwNQ==&amp;mid=200534205&amp;idx=1&amp;sn=bb86d0db54d0aa61857a2f5720bb9f70#rd'
}
*/
var DDL_CONFIG = {
	//root_url: "http://www.bangbangu.com",// by jiazom
	root_url: "./",
	//follow_url: "http://mp.weixin.qq.com/s?__biz=MzA3MDQzNzIwNQ==&mid=200534205&idx=1&sn=bb86d0db54d0aa61857a2f5720bb9f70&scene=1#rd", //by jiazom
	follow_url:try{parent.moregame();}catch(e){},
	//social_url: "http://wsq.qq.com/reflow/262979949", //by jiazom
	social_url:try{parent.moregame();}catch(e){}
	//redirect_url: "http://www.bangbangu.com",//'http://mp.weixin.qq.com/s?__biz=MzA3MDQzNzIwNQ==&mid=200534205&idx=1&sn=bb86d0db54d0aa61857a2f5720bb9f70#rd'; //by jiazom
	redirect_url: "./",;
	redirect_array : [
		//"oliverqueen.duapp.com",
		//"johndiggle.duapp.com",
		//"dinahlaurellance.duapp.com",
		//"saralance.duapp.com",
		//"tommymerlyn.duapp.com",
		//"theaqueen.duapp.com",
		//"royharper.duapp.com",
		"4399.com",
		"oliverqueen.aliapp.com",
		"johndiggle.aliapp.com",
		"dinahlaurellance.aliapp.com",
		"saralance.aliapp.com"
	],
}